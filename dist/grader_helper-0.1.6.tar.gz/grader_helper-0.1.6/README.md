Notes: 

Need to put in some functaionlity to highlight where a student submission folder has not been renamed
Also need to find a means of highlighting a student who has not submitted at the time of processing
Also need to allow for working with excel files as well as csv files
Need to add openpyxl to the dependencies in the poetry .toml file
Also need to add sphinx and generate the documentation

Have not yet integrated the 'after grading' functionality

 - Collating grades
 - Inspection of grades (Highs, Lows (and Fails), and random seleection for ML, internal and external moderation)
 - preparing student folders for return to brightspace
 - making examboard documents 
 - preparing for upload to SI portal