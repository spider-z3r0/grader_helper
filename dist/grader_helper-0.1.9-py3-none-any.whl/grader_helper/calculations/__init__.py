#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" This is the init file for the calculations module."""

from .make_letter_grade import make_letter_grade


__all__ = [
    "make_letter_grade",
]